The `boulder_buildings.shp` dataset is a subset of the dataset retrieved from the [shapefile2gif](https://github.com/johannesuhl/shapefile2gif) repo. Credits to Johannes Uhl. For more information about the datasets, check out the references below:

- Uhl, Johannes H; Leyk, Stefan (2022), "MTBF-33: A multi-temporal building footprint dataset for
  33 counties in the United States (1900–2015)", _Data in Brief_, 43, 108369. DOI: [10.1016/j.dib.2022.108369](https://doi.org/10.1016/j.dib.2022.108369)
- Uhl, Johannes H; Leyk, Stefan (2022), “MTBF-33: A multi-temporal building footprint dataset for 33 U.S. counties
  at annual resolution (1900-2015)”, _Mendeley Data_, V2. DOI: [10.17632/w33vbvjtdy.2](https://doi.org/10.17632/w33vbvjtdy.2)
